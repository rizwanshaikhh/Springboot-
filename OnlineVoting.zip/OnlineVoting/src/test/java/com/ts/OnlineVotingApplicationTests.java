package com.ts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineVotingApplicationTests {

	@Test
	void contextLoads() {
	}

}

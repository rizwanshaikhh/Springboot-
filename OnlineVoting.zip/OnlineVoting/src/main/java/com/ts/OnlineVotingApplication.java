package com.ts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineVotingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineVotingApplication.class, args);
	}

}
